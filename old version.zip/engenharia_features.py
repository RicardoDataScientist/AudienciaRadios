import pandas as pd
import numpy as np
import holidays

def gerar_features_por_regiao_v5(df: pd.DataFrame, target_region: str, feature_config: dict):
    """
    Gera features para um modelo de previsão de audiência de forma organizada e explícita,
    usando uma lista de configuração central e exibindo a lista final de todas as features criadas.

    Args:
        df (pd.DataFrame): O DataFrame original com os dados de todas as regiões.
        target_region (str): O nome da coluna da região a ser prevista 
                               (ex: 'VITORIA', 'SERRA').
        feature_config (dict): Dicionário com as configurações de features (lags e windows).

    Returns:
        tuple[pd.DataFrame, pd.Series]: Uma tupla contendo o DataFrame de 
                                         features (X) e a Série do alvo (y).
    """
    # 1. Preparação e Cópia dos Dados
    print(f"INFO: Iniciando preparação dos dados para a região '{target_region}'...")
    df_processed = df.copy()
    df_processed = df_processed.rename(columns={'PERIODO': 'Data'})
    df_processed['Data'] = pd.to_datetime(df_processed['Data'])
    df_processed = df_processed.set_index('Data').sort_index()

    # 2. Features Genéricas (baseadas no tempo)
    print("INFO: Criando features de calendário e tendência...")
    df_processed['mes'] = df_processed.index.month
    df_processed['ano'] = df_processed.index.year
    df_processed['trimestre'] = df_processed.index.quarter
    df_processed['ano_eleicao'] = (df_processed.index.year % 2 == 0).astype(int)
    
    br_holidays = holidays.Brazil(years=df_processed['ano'].unique())
    df_processed['feriados_no_mes'] = [
        sum(1 for d in br_holidays if d.month == p.month and d.year == p.year) 
        for p in df_processed.index
    ]
    
    df_processed['sin_mes'] = np.sin(2 * np.pi * df_processed['mes'] / 12)
    df_processed['cos_mes'] = np.cos(2 * np.pi * df_processed['mes'] / 12)
    df_processed['tendencia'] = np.arange(len(df_processed))
    
    calendar_features = ['mes', 'ano', 'trimestre', 'ano_eleicao', 'feriados_no_mes', 'sin_mes', 'cos_mes', 'tendencia']

    # 3. Configuração Central e Explícita de Features
    print("INFO: Montando o 'painel de controle' de features...")
    
    lags = feature_config['lags']
    windows = feature_config['windows']

    # Passo A: Definir a configuração para a variável ALVO
    config_alvo = [
        (target_region, '_target', lags, windows)
    ]
    
    # Passo B: Definir a configuração para as variáveis EXÓGENAS
    exog_cols = [c for c in df_processed.columns if c not in [target_region] + calendar_features]
    config_exogenas = [
        (col, f'_{col.lower()}', lags, []) for col in exog_cols
    ]
    
    # Passo C: Juntar tudo na lista de configuração final
    feature_configs = config_alvo + config_exogenas
    
    print("\nINFO: Plano de criação de features definido:")
    for source_col, _, lags, windows in feature_configs:
        print(f"  -> Para '{source_col}': Lags={lags}, Janelas={windows if windows else 'N/A'}")
    print("-" * 50)

    # 4. Loop Único para Criação de Features
    print("INFO: Executando plano e criando features...")
    generated_feature_names = []
    for source_col, suffix, lags, windows in feature_configs:
        for lag in lags:
            col_name = f'lag{suffix}_{lag}m'
            df_processed[col_name] = df_processed[source_col].shift(lag)
            generated_feature_names.append(col_name)

        for window in windows:
            shifted_series = df_processed[source_col].shift(1)
            mean_col_name = f'media_movel{suffix}_{window}m'
            std_col_name = f'std_movel{suffix}_{window}m'
            df_processed[mean_col_name] = shifted_series.rolling(window=window).mean()
            df_processed[std_col_name] = shifted_series.rolling(window=window).std()
            generated_feature_names.extend([mean_col_name, std_col_name])

    # 5. Montagem Final e Exibição da Lista de Features
    y = df_processed[target_region]
    all_feature_cols = calendar_features + generated_feature_names
    
    # NOVIDADE: A LISTA EXPLÍCITA QUE VOCÊ PEDIU!
    print("\n[+] INFO: Lista final com TODAS as features geradas:")
    for i, col in enumerate(all_feature_cols, 1):
        print(f"  {i:02d}. {col}")
    print("-" * 50)

    X = df_processed[all_feature_cols]

    # 6. Limpeza de NaNs e Retorno
    print("INFO: Realizando limpeza de NaNs e finalizando...")
    final_df = pd.concat([X, y], axis=1).dropna()
    
    X_final = final_df[all_feature_cols]
    y_final = final_df[target_region]

    print("INFO: Processo concluído com sucesso!")
    return X_final, y_final