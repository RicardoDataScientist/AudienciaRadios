import pandas as pd
import sys
import traceback
from config import XGB_PARAMS, SELECTION_CONFIG, PIPELINE_CONFIG, FEATURE_CONFIG

# Importa as funções dos outros scripts
from engenharia_features import gerar_features_por_regiao_v5
from selecao_features_audiencia import selecionar_features_com_refinamento
from previsao_audiencia import realizar_previsao_e_avaliar

def main():
    """
    Script principal para orquestrar o pipeline de previsão de audiência.
    """
    print("-" * 50)
    print("Pipeline de Previsão de Audiência de Rádio")
    print("-" * 50)

    # --- 1. Configuração Inicial ---
    try:
        df_original = pd.read_excel('dados/radios_audiencia.xlsx')
        print("INFO: Arquivo 'dados/radios_audiencia.xlsx' carregado com sucesso.")
    except FileNotFoundError:
        print("ERRO: O arquivo 'dados/radios_audiencia.xlsx' não foi encontrado.")
        print("Por favor, certifique-se de que o arquivo existe no diretório 'dados'.")
        sys.exit(1)

    # Listar regiões disponíveis para o usuário
    regioes_disponiveis = [col for col in df_original.columns if col not in ['PERIODO', 'COD']]
    print("\nRegiões disponíveis para análise:")
    for i, regiao in enumerate(regioes_disponiveis, 1):
        print(f"  {i}. {regiao}")

    while True:
        regiao_alvo = input("\nEscolha a região alvo (escreva o nome exatamente como na lista): ").strip().upper()
        if regiao_alvo in regioes_disponiveis:
            break
        else:
            print(f"ERRO: Região '{regiao_alvo}' inválida. Por favor, escolha uma da lista.")

    # --- 2. Engenharia de Features ---
    print(f"\n--- Iniciando Engenharia de Features para '{regiao_alvo}' ---")
    try:
        X, y = gerar_features_por_regiao_v5(df_original, regiao_alvo, FEATURE_CONFIG)
        df_completo = pd.concat([X, y], axis=1)
        print("INFO: Engenharia de features concluída.")
    except Exception as e:
        print(f"ERRO: Falha durante a engenharia de features.")
        print(traceback.format_exc())
        sys.exit(1)

    # --- 3. Seleção de Features ---
    print("\n--- Configuração da Seleção de Features ---")
    features_selecionadas = []

    while True:
        modo_selecao = input("Escolha o modo de seleção de features (manual / auto): ").strip().lower()
        if modo_selecao in ['manual', 'auto']:
            break
        else:
            print("ERRO: Opção inválida. Por favor, digite 'manual' ou 'auto'.")

    if modo_selecao == 'manual':
        print("\nModo Manual: Cole abaixo a lista de features a serem usadas.")
        print("Separe os nomes por vírgula. Ex: mes, tendencia, lag_target_1m")
        features_str = input("Features: ")
        features_selecionadas = [f.strip() for f in features_str.split(',') if f.strip()]
        
        # Validação simples
        features_invalidas = [f for f in features_selecionadas if f not in X.columns]
        if features_invalidas:
            print(f"ERRO: As seguintes features não foram encontradas: {features_invalidas}")
            print("Verifique os nomes e tente novamente.")
            sys.exit(1)

    elif modo_selecao == 'auto':
        print("\nModo Automático: Iniciando seleção de features com XGBoost.")

        while True:
            metrica_escolhida = input("Escolha a métrica de otimização para a seleção (rmse / mape): ").strip().lower()
            if metrica_escolhida in ['rmse', 'mape']:
                break
            else:
                print("ERRO: Opção inválida. Por favor, digite 'rmse' ou 'mape'.")
        
        # Carrega configurações do arquivo config.py
        FEATURES_FIXAS = SELECTION_CONFIG['features_fixas']
        FEATURES_CANDIDATAS = [col for col in X.columns if col not in FEATURES_FIXAS]
        
        fim_treino = df_completo.index.max() - pd.DateOffset(months=PIPELINE_CONFIG['tamanho_teste_selecao'])
        datas_split = {
            'inicio_treino': df_completo.index.min(),
            'fim_treino': fim_treino,
            'inicio_teste': fim_treino + pd.DateOffset(days=1),
            'fim_teste': df_completo.index.max()
        }

        try:
            print(f"\nINFO: Otimizando a seleção de features com base em '{metrica_escolhida.upper()}'.")
            melhores_features_auto = selecionar_features_com_refinamento(
                df=df_completo,
                features_candidatas=FEATURES_CANDIDATAS,
                features_fixas=FEATURES_FIXAS,
                target=regiao_alvo,
                datas_split=datas_split,
                model_params=XGB_PARAMS, # Usando XGB_PARAMS do config
                metrica_otimizacao=metrica_escolhida
            )
            features_selecionadas = FEATURES_FIXAS + melhores_features_auto
        except Exception as e:
            print(f"ERRO: Falha durante a seleção automática de features.")
            print(traceback.format_exc())
            sys.exit(1)

    if not features_selecionadas:
        print("ERRO: Nenhuma feature foi selecionada. Encerrando o script.")
        sys.exit(1)

    print("\n[+] Lista final de features que serão usadas no modelo:")
    for i, feature in enumerate(features_selecionadas, 1):
        print(f"  {i:02d}. {feature}")

    # --- 4. Previsão e Avaliação ---
    try:
        realizar_previsao_e_avaliar(
            X=X,
            y=y,
            features_selecionadas=features_selecionadas,
            regiao_alvo=regiao_alvo,
            model_params=XGB_PARAMS,
            tamanho_teste=PIPELINE_CONFIG['tamanho_teste_final']
        )
    except Exception as e:
        print(f"ERRO: Falha durante o treinamento e previsão do modelo.")
        print(traceback.format_exc())
        sys.exit(1)

    print("\n--- Pipeline concluído com sucesso! ---")

if __name__ == '__main__':
    main()
