import pandas as pd
import xgboost as xgb
import numpy as np
import traceback
from sklearn.metrics import mean_squared_error


def selecionar_features_com_refinamento(
    df: pd.DataFrame,
    features_candidatas: list,
    features_fixas: list,
    target: str,
    datas_split: dict,
    model_params: dict,
    metrica_otimizacao: str = 'rmse' # Novo parâmetro
):
    """
    Seleciona as melhores features usando uma abordagem forward com refinamento.

    Args:
        df (pd.DataFrame): DataFrame completo com todas as features e o alvo.
        features_candidatas (list): Lista de features para testar.
        features_fixas (list): Lista de features que sempre estarão no modelo.
        target (str): Nome da coluna alvo.
        datas_split (dict): Dicionário com datas de início/fim para treino e teste.
        model_params (dict): Dicionário com os parâmetros do XGBoost.
        metrica_otimizacao (str): A métrica a ser otimizada ('rmse' or 'mape').

    Returns:
        list: A lista com as melhores features candidatas selecionadas.
    """

    def treinar_e_avaliar(features: list) -> dict:
        """Treina um modelo XGBoost e retorna um dicionário com RMSE e MAPE."""
        try:
            X = df[features]
            y = df[target]

            X_train = X.loc[datas_split['inicio_treino']:datas_split['fim_treino']]
            y_train = y.loc[datas_split['inicio_treino']:datas_split['fim_treino']]
            X_test = X.loc[datas_split['inicio_teste']:datas_split['fim_teste']]
            y_test = y.loc[datas_split['inicio_teste']:datas_split['fim_teste']]

            # Evitar divisão por zero no MAPE para dados de teste com valor 0
            if (y_test == 0).any() and metrica_otimizacao == 'mape':
                y_test = y_test.replace(0, 0.001)

            model = xgb.XGBRegressor(**model_params, random_state=42)
            model.fit(X_train, y_train, eval_set=[(X_test, y_test)], early_stopping_rounds=50, verbose=False)
            
            preds = model.predict(X_test)
            rmse = np.sqrt(mean_squared_error(y_test, preds))
            mape = np.mean(np.abs((y_test - preds) / y_test)) * 100
            
            return {'rmse': rmse, 'mape': mape}
        except Exception:
            print(f"Erro ao treinar com as features: {features}")
            print(traceback.format_exc())
            return {'rmse': np.inf, 'mape': np.inf}

    features_selecionadas = []
    features_para_testar = features_candidatas.copy()
    metrica_label = metrica_otimizacao.upper()

    # Calcula o score inicial apenas com as features fixas
    metricas_iniciais = treinar_e_avaliar(features_fixas)
    score_atual = metricas_iniciais[metrica_otimizacao]
    print(f"{metrica_label} inicial (apenas features fixas): {score_atual:.6f}\n")

    iteracao = 0
    while True:
        iteracao += 1
        print(f"--- Início da Iteração {iteracao} ---")
        
        melhor_score_iteracao = score_atual
        melhor_feature_para_adicionar = None

        # Fase 1: Adição de Features
        print(f"FASE 1: Testando a adição de {len(features_para_testar)} features...")
        for feature in features_para_testar:
            features_atuais = features_fixas + features_selecionadas + [feature]
            metricas_teste = treinar_e_avaliar(features_atuais)
            score_teste = metricas_teste[metrica_otimizacao]
            print(f"  Testando ADIÇÃO de '{feature}': {metrica_label} = {score_teste:.6f}")

            if score_teste < melhor_score_iteracao:
                melhor_score_iteracao = score_teste
                melhor_feature_para_adicionar = feature
        
        if melhor_feature_para_adicionar:
            features_selecionadas.append(melhor_feature_para_adicionar)
            features_para_testar.remove(melhor_feature_para_adicionar)
            score_atual = melhor_score_iteracao
            print(f"\n=> ADICIONADA '{melhor_feature_para_adicionar}'! Novo {metrica_label}: {score_atual:.6f}\n")

            # Fase 2: Refinamento (Remoção)
            print("FASE 2: Refinando o modelo atual tentando remover features antigas...")
            while True:
                features_removiveis = [f for f in features_selecionadas if f != melhor_feature_para_adicionar]
                if not features_removiveis:
                    print("  Nenhuma feature antiga para tentar remover.")
                    break

                melhor_score_refinamento = score_atual
                feature_para_remover = None

                for feature in features_removiveis:
                    features_atuais = features_fixas + [f for f in features_selecionadas if f != feature]
                    metricas_teste = treinar_e_avaliar(features_atuais)
                    score_teste = metricas_teste[metrica_otimizacao]
                    print(f"  Testando REMOÇÃO de '{feature}': {metrica_label} = {score_teste:.6f}")

                    if score_teste < melhor_score_refinamento:
                        melhor_score_refinamento = score_teste
                        feature_para_remover = feature
                
                if feature_para_remover:
                    features_selecionadas.remove(feature_para_remover)
                    features_para_testar.append(feature_para_remover) # Devolve para a lista de candidatas
                    score_atual = melhor_score_refinamento
                    print(f"  => REMOVIDA '{feature_para_remover}'! Novo {metrica_label}: {score_atual:.6f}\n")
                else:
                    print(f"  Nenhuma remoção melhorou o {metrica_label}. Fim do refinamento.\n")
                    break
        else:
            print(f"\n--- FIM DA SELEÇÃO: Nenhuma feature adicional melhorou o modelo com base no {metrica_label}. ---")
            break
            
    return features_selecionadas