"""
Arquivo de configuração para o pipeline de previsão de audiência.
"""

# Parâmetros do modelo XGBoost
XGB_PARAMS = {
    'objective': 'reg:squarederror',
    'n_estimators': 1000,
    'learning_rate': 0.05,  # Unificado e ajustado
    'max_depth': 4,         # Ajustado para um pouco mais de complexidade
    'subsample': 0.9,       # Ajustado
    'colsample_bytree': 0.8,
    'random_state': 42,
    'n_jobs': -1
}

# Configurações da engenharia de features
FEATURE_CONFIG = {
    'lags': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    'windows': [3, 6]
}

# Configurações da seleção de features
SELECTION_CONFIG = {
    'features_fixas': ['mes', 'sin_mes', 'cos_mes', 'tendencia'],
    'metrica_otimizacao': 'mape'  # Pode ser 'rmse' ou 'mape'
}

# Configurações do pipeline
PIPELINE_CONFIG = {
    'tamanho_teste_final': 12,
    'tamanho_teste_selecao': 12
}
