import pandas as pd
import xgboost
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

import matplotlib.pyplot as plt
import numpy as np

def calcular_metricas(y_true, y_pred, label='Modelo'):
    """
    Calcula e imprime as métricas de avaliação do modelo.
    """
    mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)

    print(f"--- Avaliação do {label} ---")
    print(f"MAPE: {mape:.2f}%")
    print(f"MAE: {mae:.2f}")
    print(f"RMSE: {rmse:.2f}")
    print(f"R²: {r2:.2f}")
    print("-" * 30)
    return {'mape': mape, 'mae': mae, 'rmse': rmse, 'r2': r2}

def realizar_previsao_e_avaliar(X: pd.DataFrame, y: pd.Series, features_selecionadas: list, regiao_alvo: str, model_params: dict, tamanho_teste: int):
    """
    Treina um modelo XGBoost com as features fornecidas, avalia e plota os resultados.

    Args:
        X (pd.DataFrame): DataFrame com todas as features potenciais.
        y (pd.Series): Series com a variável alvo.
        features_selecionadas (list): Lista de nomes das colunas a serem usadas no modelo.
        regiao_alvo (str): Nome da região alvo para os títulos dos gráficos.
        model_params (dict): Dicionário com os parâmetros do XGBoost.
        tamanho_teste (int): Número de meses a serem usados para o conjunto de teste.
    """
    print("\n--- INICIANDO TREINAMENTO E PREVISÃO ---")
    print(f"Usando {len(features_selecionadas)} features selecionadas.")

    # Filtrar X para conter apenas as features selecionadas
    X_modelo = X[features_selecionadas]
    y.name = 'audiencia'

    # Divisão de Treino e Teste
    X_train, X_test = X_modelo[:-tamanho_teste], X_modelo[-tamanho_teste:]
    y_train, y_test = y[:-tamanho_teste], y[-tamanho_teste:]

    print(f"Período de Treino: {X_train.index.min().date()} a {X_train.index.max().date()}")
    print(f"Período de Teste:  {X_test.index.min().date()} a {X_test.index.max().date()}")

    # Criação da Baseline (Média Histórica Mensal)
    # Para evitar erros de sobreposição de colunas, criamos um DataFrame temporário
    # apenas com os dados necessários para a baseline.
    df_train_baseline = pd.DataFrame({'audiencia': y_train, 'mes': X.loc[y_train.index, 'mes']})
    media_mensal = df_train_baseline.groupby('mes')['audiencia'].mean()
    baseline_preds = X.loc[X_test.index, 'mes'].map(media_mensal)
    
    if baseline_preds.isnull().any():
        media_geral_treino = y_train.mean()
        baseline_preds.fillna(media_geral_treino, inplace=True)

    # Treinamento do Modelo XGBoost (usando a API Scikit-Learn para consistência)
    modelo = xgboost.XGBRegressor(**model_params)
    
    # Treina o modelo pelo número total de rodadas, sem early stopping.
    modelo.fit(X_train, y_train)

    y_pred = modelo.predict(X_test)

    # Avaliação
    calcular_metricas(y_test, y_pred, label="Modelo XGBoost")
    calcular_metricas(y_test, baseline_preds, label="Baseline (Média Histórica)")

    # Visualização
    plt.figure(figsize=(15, 6))
    plt.plot(y_test.index, y_test, label='Real', marker='o')
    plt.plot(y_test.index, y_pred, label='Previsão XGBoost', marker='x')
    plt.plot(y_test.index, baseline_preds, label='Baseline (Média Histórica)', linestyle='--')

    plt.title(f'Comparação de Previsões de Audiência para a Região: {regiao_alvo}')
    plt.xlabel('Data')
    plt.ylabel('Audiência')
    plt.legend()
    plt.grid(True)
    plt.show()